const puppeteer = require('puppeteer');
const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const temp = require('temp');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

temp.track();

class UIRenderer {
    constructor() {
        this.browser = null;
        this.tempDir = path.join(__dirname, '../temp');
        fs.ensureDirSync(this.tempDir);
    }
    
    async initBrowser() {
        if (!this.browser) {
            this.browser = await puppeteer.launch({
                headless: 'new',
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-accelerated-2d-canvas',
                    '--disable-gpu',
                    '--window-size=1080,1920'
                ]
            });
        }
        return this.browser;
    }
    
    async renderFlutterUI(dartCode, sessionId) {
        const session = sessionId || uuidv4();
        const outputDir = path.join(this.tempDir, session);
        const dartFile = path.join(outputDir, 'main.dart');
        const screenshotPath = path.join(outputDir, 'screenshot.png');
        
        try {
            await fs.ensureDir(outputDir);
            
            // Write Dart code to file
            await fs.writeFile(dartFile, dartCode);
            
            // Create pubspec.yaml
            const pubspec = `
name: flutter_ui_viewer
description: Rendered Flutter UI
version: 1.0.0

environment:
  sdk: ">=2.12.0 <3.0.0"

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.2

dev_dependencies:
  flutter_test:
    sdk: flutter

flutter:
  uses-material-design: true
            `;
            await fs.writeFile(path.join(outputDir, 'pubspec.yaml'), pubspec);
            
            // Create flutter project
            const flutterCmd = `cd ${outputDir} && flutter create --project-name=flutter_ui_viewer --org=com.example . --platforms=web 2>&1`;
            
            try {
                const { stdout, stderr } = await execPromise(flutterCmd);
                console.log('Flutter create output:', stdout);
                if (stderr) console.error('Flutter create stderr:', stderr);
            } catch (error) {
                console.error('Error creating Flutter project:', error);
                // Continue anyway, maybe project already exists
            }
            
            // Copy the Dart file to lib directory
            await fs.copy(dartFile, path.join(outputDir, 'lib', 'main.dart'));
            
            // Build web version
            console.log('Building Flutter web...');
            const buildCmd = `cd ${outputDir} && flutter build web --release 2>&1`;
            
            const { stdout, stderr } = await execPromise(buildCmd);
            console.log('Build output:', stdout);
            if (stderr) console.error('Build stderr:', stderr);
            
            // Check if build succeeded
            const buildDir = path.join(outputDir, 'build', 'web');
            if (!await fs.pathExists(buildDir)) {
                throw new Error('Failed to build Flutter web app');
            }
            
            // Start simple HTTP server
            const server = await this.startServer(buildDir, 8080);
            
            // Take screenshot with Puppeteer
            const browser = await this.initBrowser();
            const page = await browser.newPage();
            
            // Set viewport
            await page.setViewport({
                width: 1080,
                height: 1920,
                deviceScaleFactor: 2
            });
            
            // Navigate to the page
            await page.goto('http://localhost:8080', {
                waitUntil: 'networkidle0',
                timeout: 30000
            });
            
            // Wait for Flutter to load
            await page.waitForSelector('flutter-view', { timeout: 10000 }).catch(() => {});
            await page.waitForTimeout(2000);
            
            // Take screenshot
            await page.screenshot({
                path: screenshotPath,
                fullPage: true
            });
            
            // Close page but keep browser
            await page.close();
            
            // Stop server
            if (server) {
                server.close();
            }
            
            return {
                success: true,
                imagePath: screenshotPath
            };
            
        } catch (error) {
            console.error('Error rendering Flutter UI:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    startServer(directory, port) {
        return new Promise((resolve, reject) => {
            const http = require('http');
            const fs = require('fs');
            const path = require('path');
            
            const server = http.createServer((req, res) => {
                let filePath = path.join(directory, req.url === '/' ? 'index.html' : req.url);
                
                // Security check
                if (!filePath.startsWith(directory)) {
                    res.writeHead(403);
                    res.end('Forbidden');
                    return;
                }
                
                fs.readFile(filePath, (err, data) => {
                    if (err) {
                        res.writeHead(404);
                        res.end('Not found');
                        return;
                    }
                    
                    const ext = path.extname(filePath);
                    const contentType = {
                        '.html': 'text/html',
                        '.js': 'text/javascript',
                        '.css': 'text/css',
                        '.json': 'application/json',
                        '.png': 'image/png',
                        '.jpg': 'image/jpeg',
                        '.svg': 'image/svg+xml',
                        '.wasm': 'application/wasm'
                    }[ext] || 'text/plain';
                    
                    res.writeHead(200, { 'Content-Type': contentType });
                    res.end(data);
                });
            });
            
            server.listen(port, 'localhost', () => {
                resolve(server);
            }).on('error', reject);
        });
    }
    
    async cleanup(sessionId) {
        const dir = path.join(this.tempDir, sessionId);
        if (await fs.pathExists(dir)) {
            await fs.remove(dir);
        }
    }
    
    async close() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
    }
}

const renderer = new UIRenderer();

module.exports = {
    renderFlutterUI: (code, sessionId) => renderer.renderFlutterUI(code, sessionId)
};