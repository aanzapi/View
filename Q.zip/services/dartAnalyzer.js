const jsBeautify = require('js-beautify');
const fs = require('fs-extra');
const path = require('path');

class DartAnalyzer {
    analyze(dartCode) {
        const result = {
            valid: true,
            widgetName: null,
            components: [],
            error: null,
            imports: [],
            classes: []
        };
        
        try {
            // Extract imports
            const importRegex = /import\s+['"]([^'"]+)['"]/g;
            let match;
            while ((match = importRegex.exec(dartCode)) !== null) {
                result.imports.push(match[1]);
            }
            
            // Extract class names
            const classRegex = /class\s+(\w+)(?:\s+extends\s+\w+)?\s*{/g;
            let classes = [];
            while ((match = classRegex.exec(dartCode)) !== null) {
                result.classes.push(match[1]);
                if (!result.widgetName && dartCode.includes('extends StatelessWidget') || dartCode.includes('extends StatefulWidget')) {
                    result.widgetName = match[1];
                }
            }
            
            if (!result.widgetName && result.classes.length > 0) {
                result.widgetName = result.classes[0];
            }
            
            // Extract widget components
            const widgetComponents = [
                'Container', 'Column', 'Row', 'Stack', 'ListView', 
                'GridView', 'Text', 'Image', 'Icon', 'Button',
                'Card', 'Scaffold', 'AppBar', 'FloatingActionButton',
                'TextField', 'Checkbox', 'Radio', 'Slider', 'Switch'
            ];
            
            widgetComponents.forEach(component => {
                const regex = new RegExp(`<${component}|${component}\\(`, 'g');
                const count = (dartCode.match(regex) || []).length;
                if (count > 0) {
                    result.components.push(`${component} (${count}x)`);
                }
            });
            
            // Validate Flutter code
            if (!dartCode.includes('import \'package:flutter/material.dart\'')) {
                result.valid = false;
                result.error = 'Missing Flutter import. Add: import \'package:flutter/material.dart\';';
                return result;
            }
            
            if (!dartCode.includes('Widget build(')) {
                result.valid = false;
                result.error = 'No build method found. Make sure your widget has a build method.';
                return result;
            }
            
            if (result.classes.length === 0) {
                result.valid = false;
                result.error = 'No class found in the file.';
                return result;
            }
            
        } catch (error) {
            result.valid = false;
            result.error = error.message;
        }
        
        return result;
    }
    
    async extractWidgets(dartCode) {
        const widgets = [];
        
        // Extract StatelessWidget
        const statelessRegex = /class\s+(\w+)\s+extends\s+StatelessWidget\s*{([^}]*)}/g;
        let match;
        while ((match = statelessRegex.exec(dartCode)) !== null) {
            widgets.push({
                name: match[1],
                type: 'StatelessWidget',
                code: match[0]
            });
        }
        
        // Extract StatefulWidget
        const statefulRegex = /class\s+(\w+)\s+extends\s+StatefulWidget\s*{([^}]*)}/g;
        while ((match = statefulRegex.exec(dartCode)) !== null) {
            widgets.push({
                name: match[1],
                type: 'StatefulWidget',
                code: match[0]
            });
        }
        
        return widgets;
    }
    
    generateCompleteCode(dartCode, widgetName) {
        // If code already has main() function, return as is
        if (dartCode.includes('void main()')) {
            return dartCode;
        }
        
        // Otherwise, wrap in a complete app
        return `
import 'package:flutter/material.dart';

${dartCode}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter UI Viewer',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ${widgetName || 'MyWidget'}(),
    );
  }
}
        `;
    }
}

module.exports = { analyzeDartFile: (code) => new DartAnalyzer().analyze(code) };