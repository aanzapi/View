#!/bin/bash

# Telegram Flutter UI Viewer Bot - Setup Script
# Run: chmod +x setup.sh && ./setup.sh

set -e

echo "🚀 Installing Telegram Flutter UI Viewer Bot..."
echo "=================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo -e "${RED}⚠️  Please do not run as root!${NC}"
   exit 1
fi

# Update system
echo -e "${YELLOW}📦 Updating system packages...${NC}"
sudo apt update && sudo apt upgrade -y

# Install Node.js 18+
echo -e "${YELLOW}📦 Installing Node.js...${NC}"
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install Flutter/Dart
echo -e "${YELLOW}📦 Installing Flutter...${NC}"
cd ~
if [ ! -d "flutter" ]; then
    wget https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.19.0-stable.tar.xz
    tar xf flutter_linux_3.19.0-stable.tar.xz
    rm flutter_linux_3.19.0-stable.tar.xz
fi

# Add Flutter to PATH
echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.bashrc
export PATH="$PATH:$HOME/flutter/bin"

# Install dependencies
echo -e "${YELLOW}📦 Installing additional packages...${NC}"
sudo apt install -y \
    git \
    curl \
    wget \
    imagemagick \
    chromium-browser \
    xvfb \
    libglu1-mesa \
    x11-utils

# Install Puppeteer dependencies
sudo apt install -y \
    ca-certificates \
    fonts-liberation \
    libappindicator3-1 \
    libasound2 \
    libatk-bridge2.0-0 \
    libatk1.0-0 \
    libcups2 \
    libdbus-1-3 \
    libgbm1 \
    libgtk-3-0 \
    libnspr4 \
    libnss3 \
    libx11-xcb1 \
    libxcomposite1 \
    libxdamage1 \
    libxrandr2 \
    xdg-utils

# Create project directory
mkdir -p ~/telegram-flutter-viewer-bot
cd ~/telegram-flutter-viewer-bot

# Initialize Node.js project
echo -e "${YELLOW}📦 Initializing Node.js project...${NC}"
npm init -y

# Install required packages
echo -e "${YELLOW}📦 Installing NPM packages...${NC}"
npm install \
    dotenv \
    node-telegram-bot-api \
    puppeteer \
    express \
    multer \
    cors \
    chalk \
    fs-extra \
    js-beautify \
    temp \
    uuid

# Create directory structure
mkdir -p services temp views public/uploads

# Create environment file
cat > .env << 'EOF'
TELEGRAM_BOT_TOKEN=YOUR_BOT_TOKEN_HERE
PORT=3000
ALLOWED_USERS=*
MAX_FILE_SIZE=5242880
EOF

echo -e "${GREEN}✅ Setup completed!${NC}"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Get your bot token from @BotFather on Telegram"
echo "2. Edit .env file and add your token"
echo "3. Run: node index.js"
echo ""
echo -e "${GREEN}To start the bot:${NC}"
echo "cd ~/telegram-flutter-viewer-bot && node index.js"