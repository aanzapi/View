require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const express = require('express');
const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');
const multer = require('multer');
const cors = require('cors');
const { analyzeDartFile, extractUIComponents } = require('./services/dartAnalyzer');
const { renderFlutterUI } = require('./services/uiRenderer');

// Configuration
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const PORT = process.env.PORT || 3000;
const ALLOWED_USERS = process.env.ALLOWED_USERS === '*' ? null : process.env.ALLOWED_USERS?.split(',');
const MAX_FILE_SIZE = parseInt(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024; // 5MB

if (!BOT_TOKEN) {
    console.error(chalk.red('❌ TELEGRAM_BOT_TOKEN not found in .env file!'));
    process.exit(1);
}

// Initialize bot
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, 'temp'));
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    }
});
const upload = multer({ 
    storage, 
    limits: { fileSize: MAX_FILE_SIZE },
    fileFilter: (req, file, cb) => {
        if (file.originalname.endsWith('.dart')) {
            cb(null, true);
        } else {
            cb(new Error('Only .dart files are allowed'));
        }
    }
});

// Temporary storage for user sessions
const userSessions = new Map();

// Helper function to check if user is allowed
function isUserAllowed(userId) {
    if (!ALLOWED_USERS) return true;
    return ALLOWED_USERS.includes(userId.toString());
}

// Helper function to send message with error handling
async function safeSendMessage(chatId, text, options = {}) {
    try {
        return await bot.sendMessage(chatId, text, options);
    } catch (error) {
        console.error(chalk.red(`Failed to send message to ${chatId}:`, error.message));
    }
}

// Helper function to send photo with error handling
async function safeSendPhoto(chatId, photo, caption = '', options = {}) {
    try {
        return await bot.sendPhoto(chatId, photo, { caption, ...options });
    } catch (error) {
        console.error(chalk.red(`Failed to send photo to ${chatId}:`, error.message));
        await safeSendMessage(chatId, '❌ Failed to render UI. Please check your Flutter code.');
    }
}

// Start command
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!isUserAllowed(userId)) {
        return safeSendMessage(chatId, '⛔ Access denied. You are not authorized to use this bot.');
    }
    
    const welcomeMessage = `
🌟 *Welcome to Flutter UI Viewer Bot!* 🌟

I can help you visualize Flutter UI from your .dart files.

*Commands:*
📤 /upload - Upload a .dart file to view UI
🎨 /example - View example Flutter UI
📖 /help - Show this help message
🔧 /status - Check bot status

*How to use:*
1. Send me a .dart file containing Flutter widgets
2. I'll analyze and render the UI
3. You'll receive a screenshot of the rendered UI

*Supported widgets:*
- Container, Column, Row
- Text, Image, Icon
- ListView, GridView
- Card, ElevatedButton
- And many more!

Made with ❤️ for Flutter developers
    `;
    
    await safeSendMessage(chatId, welcomeMessage, { parse_mode: 'Markdown' });
});

// Help command
bot.onText(/\/help/, async (msg) => {
    const chatId = msg.chat.id;
    const helpMessage = `
📖 *Flutter UI Viewer Bot - Help*

*Commands:*
/start - Start the bot
/upload - Upload a .dart file
/example - View example UI
/status - Check bot status
/help - Show this help

*File requirements:*
• File must be .dart extension
• Max size: 5MB
• Must contain valid Flutter widgets

*Tips:*
1. Make sure your Flutter code is complete
2. Include import statements
3. Use proper widget structure
4. The widget will be rendered in a MaterialApp

*Example usage:*
Send a file named 'my_widget.dart' containing:
\`\`\`dart
import 'package:flutter/material.dart';

class MyWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Hello Flutter!'),
      ),
    );
  }
}
\`\`\`

*Need help?* Contact @your_username
    `;
    
    await safeSendMessage(chatId, helpMessage, { parse_mode: 'Markdown' });
});

// Upload command
bot.onText(/\/upload/, async (msg) => {
    const chatId = msg.chat.id;
    
    await safeSendMessage(chatId, '📤 Please send me your .dart file. Make sure it contains Flutter widget code!');
    
    // Set waiting for file state
    userSessions.set(chatId, { waitingForFile: true });
});

// Example command
bot.onText(/\/example/, async (msg) => {
    const chatId = msg.chat.id;
    
    await safeSendMessage(chatId, '🎨 Generating example Flutter UI...');
    
    const exampleCode = `
import 'package:flutter/material.dart';

class ExampleWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Flutter UI Viewer Example'),
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.flutter_dash,
                size: 100,
                color: Colors.blue,
              ),
              SizedBox(height: 20),
              Text(
                'Flutter UI Viewer',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Your UI will appear here!',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {},
                child: Text('Sample Button'),
              ),
              SizedBox(height: 20),
              Card(
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    'This is a sample card widget.\nSend your own .dart file to render custom UI!',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
    `;
    
    try {
        const result = await renderFlutterUI(exampleCode, chatId);
        if (result.success) {
            await safeSendPhoto(chatId, result.imagePath, '✨ *Example Flutter UI* ✨\n\nHere\'s a sample of what I can render!', { parse_mode: 'Markdown' });
            await fs.remove(result.imagePath);
        } else {
            await safeSendMessage(chatId, `❌ Failed to render example: ${result.error}`);
        }
    } catch (error) {
        console.error(chalk.red('Error rendering example:', error));
        await safeSendMessage(chatId, '❌ Error rendering example. Please try again.');
    }
});

// Status command
bot.onText(/\/status/, async (msg) => {
    const chatId = msg.chat.id;
    
    const statusMessage = `
🔧 *Bot Status*

✅ Bot is running
✅ Telegram API connected
✅ Flutter SDK: ${await checkFlutterVersion()}
📊 Memory usage: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB
🕐 Uptime: ${formatUptime(process.uptime())}
👥 Active sessions: ${userSessions.size}

*System Info:*
• Node.js: ${process.version}
• Platform: ${process.platform}
• Architecture: ${process.arch}
    `;
    
    await safeSendMessage(chatId, statusMessage, { parse_mode: 'Markdown' });
});

// Handle file uploads
bot.on('document', async (msg) => {
    const chatId = msg.chat.id;
    const session = userSessions.get(chatId);
    
    if (!session || !session.waitingForFile) {
        return;
    }
    
    const file = msg.document;
    const fileName = file.file_name;
    
    if (!fileName.endsWith('.dart')) {
        await safeSendMessage(chatId, '❌ Please send a .dart file!');
        userSessions.delete(chatId);
        return;
    }
    
    if (file.file_size > MAX_FILE_SIZE) {
        await safeSendMessage(chatId, `❌ File too large! Maximum size: ${MAX_FILE_SIZE / 1024 / 1024}MB`);
        userSessions.delete(chatId);
        return;
    }
    
    await safeSendMessage(chatId, '📥 Processing your Flutter file... This may take a moment.');
    
    try {
        // Download file
        const fileLink = await bot.getFileLink(file.file_id);
        const response = await fetch(fileLink);
        const dartCode = await response.text();
        
        // Analyze file
        const analysis = await analyzeDartFile(dartCode);
        
        if (!analysis.valid) {
            await safeSendMessage(chatId, `❌ Invalid Flutter code:\n\`\`\`\n${analysis.error}\n\`\`\``, { parse_mode: 'Markdown' });
            userSessions.delete(chatId);
            return;
        }
        
        await safeSendMessage(chatId, `🔍 Analysis complete!\n📄 Widget: ${analysis.widgetName}\n📦 Components: ${analysis.components.length}\n🎨 Rendering UI...`);
        
        // Render UI
        const result = await renderFlutterUI(dartCode, chatId);
        
        if (result.success) {
            await safeSendPhoto(chatId, result.imagePath, `✨ *${analysis.widgetName}* ✨\n\n${analysis.components.map(c => `• ${c}`).join('\n')}`, { parse_mode: 'Markdown' });
            await fs.remove(result.imagePath);
        } else {
            await safeSendMessage(chatId, `❌ Failed to render UI:\n\`\`\`\n${result.error}\n\`\`\``, { parse_mode: 'Markdown' });
        }
        
    } catch (error) {
        console.error(chalk.red('Error processing file:', error));
        await safeSendMessage(chatId, `❌ Error processing file: ${error.message}`);
    } finally {
        userSessions.delete(chatId);
    }
});

// Handle messages
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;
    
    // Ignore commands
    if (text && text.startsWith('/')) return;
    
    // Check if waiting for file
    if (userSessions.has(chatId) && userSessions.get(chatId).waitingForFile) {
        await safeSendMessage(chatId, '📤 Please send a .dart file (as document), not text.');
    }
});

// Helper functions
async function checkFlutterVersion() {
    try {
        const { execSync } = require('child_process');
        const version = execSync('flutter --version', { encoding: 'utf8' });
        const match = version.match(/Flutter (\d+\.\d+\.\d+)/);
        return match ? match[1] : 'Unknown';
    } catch (error) {
        return 'Not installed';
    }
}

function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m ${secs}s`;
    if (minutes > 0) return `${minutes}m ${secs}s`;
    return `${secs}s`;
}

// Express routes
app.get('/', (req, res) => {
    res.json({
        name: 'Telegram Flutter UI Viewer Bot',
        version: '1.0.0',
        status: 'running',
        bot: BOT_TOKEN ? 'configured' : 'missing token'
    });
});

app.post('/api/render', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    try {
        const dartCode = await fs.readFile(req.file.path, 'utf8');
        const result = await renderFlutterUI(dartCode, 'api');
        
        if (result.success) {
            res.json({ success: true, image: result.imagePath });
        } else {
            res.status(400).json({ success: false, error: result.error });
        }
        
        await fs.remove(req.file.path);
        if (result.success) await fs.remove(result.imagePath);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(chalk.green(`✅ Server running on port ${PORT}`));
    console.log(chalk.blue(`🤖 Bot is running...`));
    console.log(chalk.yellow(`📱 Send /start to @${bot.getMe().then(me => me.username)} on Telegram`));
});

// Error handling
process.on('unhandledRejection', (reason, promise) => {
    console.error(chalk.red('Unhandled Rejection at:', promise, 'reason:', reason));
});

process.on('uncaughtException', (error) => {
    console.error(chalk.red('Uncaught Exception:', error));
});

console.log(chalk.green('🚀 Bot started successfully!'));