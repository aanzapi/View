const queue = []
let running = false

async function runQueue(worker){

if(running) return
running = true

while(queue.length){

const job = queue.shift()

try{
await worker(job)
}catch(e){
console.log(e)
}

}

running = false

}

module.exports = { queue, runQueue }