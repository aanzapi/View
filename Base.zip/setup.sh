#!/bin/bash

echo "UPDATE VPS"

apt update -y
apt upgrade -y

apt install -y git curl unzip xz-utils zip nodejs npm chromium-browser

echo "INSTALL FLUTTER"

cd /root
git clone https://github.com/flutter/flutter.git -b stable

echo 'export PATH="$PATH:/root/flutter/bin"' >> ~/.bashrc
source ~/.bashrc

flutter doctor

echo "SETUP BOT"

mkdir dart-ui-bot
cd dart-ui-bot

npm init -y
npm install node-telegram-bot-api fs-extra puppeteer

mkdir temp
mkdir template

echo "CREATE TEMPLATE FLUTTER"

flutter create template/app

echo "DONE"
echo "Upload bot.js lalu jalankan:"
echo "node bot.js"