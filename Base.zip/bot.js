const TelegramBot = require("node-telegram-bot-api")
const fs = require("fs-extra")
const { execSync } = require("child_process")
const puppeteer = require("puppeteer")
const path = require("path")
const { queue, runQueue } = require("./queue")

const TOKEN = "8126542206:AAHoVsFX3QfNyCNh90_ywsn-AOZo29wnfuY"

const bot = new TelegramBot(TOKEN,{polling:true})

const templatePath = "/root/dart-ui-bot/template/app"

const tempPath = "/root/dart-ui-bot/temp"

const cooldown = {}

bot.on("message", async msg => {

if(!msg.document) return

const chatId = msg.chat.id
const user = msg.from.id

if(cooldown[user]){
bot.sendMessage(chatId,"⏳ Tunggu 10 detik")
return
}

cooldown[user] = true
setTimeout(()=> delete cooldown[user],10000)

const fileName = msg.document.file_name

if(!fileName.endsWith(".dart")){
bot.sendMessage(chatId,"❌ Kirim file .dart")
return
}

const file = await bot.getFile(msg.document.file_id)

const url = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`

queue.push({
chatId,
url
})

bot.sendMessage(chatId,"📦 Masuk queue render")

runQueue(worker)

})

async function worker(job){

const { chatId, url } = job

bot.sendMessage(chatId,"⚙️ Rendering UI...")

const id = Date.now()

const project = `${tempPath}/app_${id}`

await fs.copy(templatePath,project)

const res = await fetch(url)

const buffer = await res.arrayBuffer()

fs.writeFileSync(`${project}/lib/main.dart`,Buffer.from(buffer))

execSync(`cd ${project} && flutter build web`,{stdio:"ignore"})

const browser = await puppeteer.launch({
args:["--no-sandbox"]
})

const page = await browser.newPage()

await page.goto(`file://${project}/build/web/index.html`)

await page.setViewport({
width:400,
height:800
})

await page.waitForTimeout(4000)

const img = `${project}/preview.png`

await page.screenshot({path:img})

await browser.close()

await bot.sendPhoto(chatId,img)

fs.removeSync(project)

}