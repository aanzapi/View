require("dotenv").config()
const { Telegraf } = require("telegraf")
const fs = require("fs")
const { execSync } = require("child_process")
const path = require("path")

const bot = new Telegraf(process.env.BOT_TOKEN)

const WORK_DIR = "/tmp/flutter_render"

if (!fs.existsSync(WORK_DIR)) {
    fs.mkdirSync(WORK_DIR, { recursive: true })
}

bot.start(ctx => {
    ctx.reply("Kirim file .dart untuk di render UI 📸")
})

bot.on("document", async (ctx) => {
    const file = ctx.message.document

    if (!file.file_name.endsWith(".dart")) {
        return ctx.reply("❌ Harus file .dart")
    }

    try {
        const fileLink = await ctx.telegram.getFileLink(file.file_id)
        const dartPath = path.join(WORK_DIR, "main.dart")

        const response = await fetch(fileLink.href)
        const buffer = await response.arrayBuffer()
        fs.writeFileSync(dartPath, Buffer.from(buffer))

        ctx.reply("⚙️ Sedang render UI...")

        const projectDir = path.join(WORK_DIR, "app")

        if (fs.existsSync(projectDir)) {
            execSync(`rm -rf ${projectDir}`)
        }

        execSync(`flutter create ${projectDir}`, { stdio: "ignore" })

        fs.copyFileSync(dartPath, path.join(projectDir, "lib/main.dart"))

        execSync(`cd ${projectDir} && flutter pub get`, { stdio: "ignore" })

        execSync(`cd ${projectDir} && flutter build apk`, { stdio: "ignore" })

        execSync(`cd ${projectDir} && flutter emulators --launch flutter_emulator`, { stdio: "ignore" })

        execSync(`cd ${projectDir} && flutter run -d emulator-5554 --no-sound-null-safety`, { stdio: "ignore" })

        execSync(`adb exec-out screencap -p > ${WORK_DIR}/screen.png`)

        await ctx.replyWithPhoto({ source: `${WORK_DIR}/screen.png` })

        execSync(`adb emu kill`)

    } catch (err) {
        console.log(err)
        ctx.reply("❌ Gagal render UI")
    }
})

bot.launch()
console.log("Bot jalan 🔥")