#!/bin/bash

apt update
apt install -y curl git unzip xz-utils zip libglu1-mesa adb openjdk-17-jdk

# Install Node 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install Flutter
cd /opt
git clone https://github.com/flutter/flutter.git
export PATH="$PATH:/opt/flutter/bin"
echo 'export PATH="$PATH:/opt/flutter/bin"' >> ~/.bashrc

flutter doctor

# Install Android SDK minimal
apt install -y android-sdk

npm install

echo "SETUP SELESAI 🔥"