const { Telegraf } = require('telegraf');
const fs = require('fs').promises;
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const express = require('express');
const puppeteer = require('puppeteer');

const execPromise = util.promisify(exec);
const BOT_TOKEN = process.env.BOT_TOKEN || 'YOUR_BOT_TOKEN_HERE';

if (!process.env.BOT_TOKEN && BOT_TOKEN === 'YOUR_BOT_TOKEN_HERE') {
  console.error('❌ Please set BOT_TOKEN environment variable');
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);
const app = express();
const PORT = process.env.PORT || 3000;

// Setup web server for health check
app.get('/', (req, res) => {
  res.send('Flutter UI Render Bot is running!');
});

app.listen(PORT, () => {
  console.log(`🌐 Web server running on port ${PORT}`);
});

// Create temp directory
const TEMP_DIR = path.join(__dirname, 'temp');
const RENDER_DIR = path.join(TEMP_DIR, 'render_project');

async function ensureDir() {
  try {
    await fs.mkdir(TEMP_DIR, { recursive: true });
    await fs.mkdir(RENDER_DIR, { recursive: true });
  } catch (error) {
    console.error('Error creating directories:', error);
  }
}

async function createFlutterProject(code, fileName) {
  const projectPath = path.join(RENDER_DIR, fileName.replace('.dart', ''));
  
  try {
    // Create Flutter project if not exists
    try {
      await fs.access(projectPath);
    } catch {
      console.log(`Creating Flutter project at ${projectPath}...`);
      await execPromise(`flutter create --project-name=temp_ui --org=com.example ${projectPath}`);
    }
    
    // Backup and replace main.dart
    const mainDartPath = path.join(projectPath, 'lib', 'main.dart');
    await fs.writeFile(mainDartPath, code);
    
    return projectPath;
  } catch (error) {
    throw new Error(`Failed to create Flutter project: ${error.message}`);
  }
}

async function renderFlutterUI(projectPath) {
  const screenshotPath = path.join(TEMP_DIR, `screenshot_${Date.now()}.png`);
  
  try {
    // Build web version
    console.log('Building web version...');
    await execPromise(`cd ${projectPath} && flutter build web --release`);
    
    // Start local server
    const webPath = path.join(projectPath, 'build', 'web');
    const serverUrl = `http://localhost:8080`;
    
    console.log('Launching browser...');
    const browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    await page.setViewport({ width: 375, height: 812 }); // Mobile view
    
    // Serve the web files
    const expressApp = express();
    expressApp.use(express.static(webPath));
    
    const server = expressApp.listen(8080, async () => {
      console.log(`Serving at ${serverUrl}`);
      
      try {
        await page.goto(serverUrl, { waitUntil: 'networkidle0', timeout: 10000 });
        await page.waitForTimeout(2000); // Wait for Flutter to initialize
        
        await page.screenshot({ path: screenshotPath, fullPage: true });
        console.log(`Screenshot saved: ${screenshotPath}`);
        
        await browser.close();
        server.close();
      } catch (error) {
        console.error('Error capturing screenshot:', error);
        server.close();
        await browser.close();
        throw error;
      }
    });
    
    return screenshotPath;
  } catch (error) {
    console.error('Render error:', error);
    throw new Error(`Failed to render UI: ${error.message}`);
  }
}

async function cleanupTempFiles(screenshotPath) {
  try {
    if (screenshotPath && await fs.access(screenshotPath).then(() => true).catch(() => false)) {
      await fs.unlink(screenshotPath);
    }
  } catch (error) {
    console.error('Cleanup error:', error);
  }
}

bot.start((ctx) => {
  ctx.reply(
    '🎨 *Flutter UI Render Bot*\n\n' +
    'Send me a `.dart` file with Flutter code, and I\'ll render it!\n\n' +
    '*Requirements:*\n' +
    '• Must be a complete Flutter app\n' +
    '• Should have a `main()` function\n' +
    '• Use `MaterialApp` as root widget\n\n' +
    '*Example:*\n' +
    '```dart\n' +
    "import 'package:flutter/material.dart';\n\n" +
    'void main() => runApp(MyApp());\n\n' +
    'class MyApp extends StatelessWidget {\n' +
    '  @override\n' +
    '  Widget build(BuildContext context) {\n' +
    "    return MaterialApp(\n" +
    "      home: Scaffold(\n" +
    "        appBar: AppBar(title: Text('Hello')),\n" +
    "        body: Center(child: Text('World!')),\n" +
    "      ),\n" +
    '    );\n' +
    '  }\n' +
    '}\n' +
    '```',
    { parse_mode: 'Markdown' }
  );
});

bot.on('document', async (ctx) => {
  const message = ctx.message;
  const document = message.document;
  
  if (!document.file_name.endsWith('.dart')) {
    return ctx.reply('❌ Please send a `.dart` file only!');
  }
  
  const waitMessage = await ctx.reply('🎨 Processing your Flutter code... This may take 30-60 seconds.');
  
  let screenshotPath = null;
  
  try {
    await ensureDir();
    
    // Download file
    const fileLink = await ctx.telegram.getFileLink(document.file_id);
    const response = await fetch(fileLink.toString());
    const code = await response.text();
    
    // Validate code
    if (!code.includes('main(') || !code.includes('MaterialApp')) {
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        waitMessage.message_id,
        undefined,
        '⚠️ Invalid Flutter code!\n\nMake sure your code:\n• Has a `main()` function\n• Uses `MaterialApp` as root widget\n• Imports flutter/material.dart'
      );
      return;
    }
    
    // Create Flutter project
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      waitMessage.message_id,
      undefined,
      '📦 Creating Flutter project...'
    );
    
    const projectPath = await createFlutterProject(code, document.file_name);
    
    // Render UI
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      waitMessage.message_id,
      undefined,
      '🎨 Rendering UI... (this may take a moment)'
    );
    
    screenshotPath = await renderFlutterUI(projectPath);
    
    // Send screenshot
    await ctx.telegram.sendPhoto(
      ctx.chat.id,
      { source: screenshotPath },
      {
        caption: `✅ *Rendered successfully!*\n📄 File: ${document.file_name}\n\n⚡ *Tip:* Make sure to use proper Flutter widgets for best results.`,
        parse_mode: 'Markdown'
      }
    );
    
    await ctx.deleteMessage(waitMessage.message_id);
    
  } catch (error) {
    console.error('Error:', error);
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      waitMessage.message_id,
      undefined,
      `❌ *Error:* ${error.message}\n\nPlease check your Flutter code and try again.`,
      { parse_mode: 'Markdown' }
    );
  } finally {
    if (screenshotPath) {
      await cleanupTempFiles(screenshotPath);
    }
  }
});

bot.catch((err, ctx) => {
  console.error('Bot error:', err);
  ctx.reply('❌ An unexpected error occurred. Please try again.');
});

console.log('🤖 Flutter UI Render Bot started!');
bot.launch();

// Graceful shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));