#!/bin/bash

echo "🚀 Setting up Flutter UI Render Bot..."

# Update system
echo "📦 Updating system packages..."
sudo apt-get update
sudo apt-get upgrade -y

# Install dependencies
echo "📦 Installing dependencies..."
sudo apt-get install -y curl git wget unzip xvfb libgbm1 libxshmfence1 \
    libglib2.0-0 libnss3 libatk-bridge2.0-0 libgtk-3-0 libdrm2 \
    libxcomposite1 libxdamage1 libxrandr2 libgbm1 libxkbcommon0 \
    libasound2 libatspi2.0-0 libcups2

# Install Node.js 18+
echo "📦 Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install Flutter
echo "📦 Installing Flutter..."
cd ~
wget -q https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.16.9-stable.tar.xz
tar -xf flutter_linux_3.16.9-stable.tar.xz
echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.bashrc
export PATH="$PATH:$HOME/flutter/bin"

# Pre-download Flutter artifacts
echo "📦 Pre-downloading Flutter artifacts..."
flutter precache
flutter doctor --no-analytics

# Accept Android licenses (if needed)
echo "📦 Configuring Flutter..."
yes | flutter doctor --android-licenses 2>/dev/null || true

# Install Chrome/Chromium for Puppeteer
echo "📦 Installing Chromium..."
sudo apt-get install -y chromium-browser

# Setup project
echo "📦 Setting up project..."
cd /root/flutter-ui-bot || exit

# Install Node dependencies
echo "📦 Installing Node dependencies..."
npm install

# Create temp directory
mkdir -p temp

# Create systemd service
echo "📦 Creating systemd service..."
sudo tee /etc/systemd/system/flutter-ui-bot.service > /dev/null <<EOF
[Unit]
Description=Flutter UI Render Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/flutter-ui-bot
ExecStart=/usr/bin/node /root/flutter-ui-bot/bot.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=BOT_TOKEN=YOUR_BOT_TOKEN_HERE

[Install]
WantedBy=multi-user.target
EOF

# Create .env file
echo "📦 Creating .env file..."
cat > .env <<EOF
BOT_TOKEN=YOUR_BOT_TOKEN_HERE
PORT=3000
EOF

echo ""
echo "✅ Setup completed!"
echo ""
echo "⚠️  IMPORTANT: Edit the .env file and add your BOT_TOKEN:"
echo "   nano .env"
echo ""
echo "Then start the bot:"
echo "   sudo systemctl start flutter-ui-bot"
echo "   sudo systemctl enable flutter-ui-bot"
echo ""
echo "Check status:"
echo "   sudo systemctl status flutter-ui-bot"
echo ""
echo "View logs:"
echo "   sudo journalctl -u flutter-ui-bot -f"